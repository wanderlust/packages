;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wanderlust-utils" "20250531.1243"
  "Utilities for Wanderlust."
  '((emacs      "24.5")
    (wanderlust "2.15.9"))
  :commit "d83661ae59ea7ba2fe0c9e362ac314d4b921ffd4"
  :revdesc "d83661ae59ea"
  :maintainers '(("Kazuhiro Ito" . "kzhr@d1.dion.ne.jp")))
